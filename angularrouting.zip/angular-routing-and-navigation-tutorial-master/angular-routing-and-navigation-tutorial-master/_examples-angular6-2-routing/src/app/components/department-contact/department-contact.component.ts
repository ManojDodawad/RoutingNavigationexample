import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-contact',
  templateUrl: './department-contact.component.html',
  styleUrls: ['./department-contact.component.css']
})
export class DepartmentContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
